using System;

namespace SHAB.Presentation {
	public partial class shgn_bt_se_button_ILUS_TE_UL_LIMITATION : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

