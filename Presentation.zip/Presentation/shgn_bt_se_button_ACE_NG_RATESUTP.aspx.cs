using System;

namespace SHAB.Presentation {
	public partial class shgn_bt_se_button_ACE_NG_RATESUTP : SHMA.CodeVision.Presentation.ButtonbarBase{
 
	}
}

